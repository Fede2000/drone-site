﻿import csv
import json
import os
import pandas as pd


csvList=os.listdir("products/")




file = 'products/Chargers.csv'
json_file = 'Json_p/output_file_name.json'



#Read CSV File
def read_CSV(file, json_file):
    dataframe = pd.read_csv(file)
    with open(json_file, 'w', encoding='utf-8') as f:
        dataframe.to_json(f, orient='records', lines=False, force_ascii=False)   #orient='records', lines=True
    #dataframe.to_json(json_file)
    print(dataframe)

fnL = []
for fn in csvList:
    filename, file_extension = os.path.splitext(fn)
    read_CSV("products/" + filename + ".csv", "Json_p/" + filename + ".json")
    fnL.append(filename)

json_folder_path = "Json_p/"

json_files = [ x for x in os.listdir(json_folder_path) if x.endswith("json") ]
json_data = list()
for json_file in fnL:
    json_file_path = os.path.join(json_folder_path, json_file + ".json")
    with open (json_file_path, "r",encoding='utf-8') as f:
        json_data.append({"name":json_file,"data":json.load(f)})


new_obj = {"main":json_data}
new_obj

output_path = "output.json"
with open (output_path, "w", encoding='utf-8') as f:
    str_ = json.dump(new_obj,f, indent=4, sort_keys=True, ensure_ascii=False)
    #f.write(to_unicode(str_))
    #json.dump(json_data, f, indent=4 )#,  sort_keys=False, indent=4, separators=(',', ': '))
